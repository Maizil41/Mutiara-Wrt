const express = require("express");
const { execFile } = require("child_process");
const path = require("path");
const fs = require("fs").promises;

const app = express();
const PORT = 3000;

const API_KEY = "9fab538d-0a81-4693-85ed-80a3d361d826";

const USER_RE = /^[A-Za-z0-9_-]{1,32}$/;
const isValidUsername = (u) => USER_RE.test(u);

function rand4() {
  return String(Math.floor(Math.random() * 10000)).padStart(4, "0");
}
function makeUsernameWithRandom4(base) {
  const suffix = rand4();
  const maxLen = 32;
  const allowedBaseLen = Math.max(0, maxLen - suffix.length);
  const trimmedBase = String(base).slice(0, allowedBaseLen);
  return trimmedBase + suffix;
}

const SUPPORTED = {
  trojan: {
    script: "m-trojan-auto.exp",
    filePrefix: "trojan-",
  },
  vless: {
    script: "m-vless-auto.exp",
    filePrefix: "vless-",
  },
  vmess: {
    script: "m-vmess-auto.exp",
    filePrefix: "vmess-",
  },
};

async function handleAccount(req, res) {
  if (req.query.key !== API_KEY) {
    return res.status(403).json({
      status: "error",
      message: "API key salah atau tidak diberikan.",
    });
  }

  const type = String(req.params.type || "").toLowerCase();

  if (!SUPPORTED[type]) {
    return res.status(400).json({
      status: "error",
      message: "Tipe tidak didukung. Gunakan: trojan, vless, atau vmess.",
    });
  }

  const { username, exp, quota, iplimit } = req.query;

  if (!username || !exp || quota === undefined || !iplimit) {
    return res.status(400).json({
      status: "error",
      message:
        "Parameter tidak lengkap. Contoh: ?key=APIKEY&username=alok&exp=30&quota=0&iplimit=1",
    });
  }
  if (!isValidUsername(username)) {
    return res.status(400).json({
      status: "error",
      message: "Username tidak valid (huruf/angka/_/-, maks 32).",
    });
  }

  const finalUsername = makeUsernameWithRandom4(username);

  const scriptPath = path.join(__dirname, SUPPORTED[type].script);
  const args = [String(finalUsername), String(exp), String(quota), String(iplimit)];

  execFile(scriptPath, args, async (error, stdout, stderr) => {
    if (error) {
      return res.status(500).json({
        status: "error",
        message: `Gagal menjalankan script ${SUPPORTED[type].script}: ${error.message}`,
      });
    }
    if (stderr && stderr.trim()) {
      console.warn(`[${type}] stderr:`, stderr);
    }

    const filePath = `/var/www/html/${SUPPORTED[type].filePrefix}${finalUsername}.txt`;

    try {
      const content = await fs.readFile(filePath, "utf8");
      res.type("text/plain").send(content);
    } catch (e) {
      return res.status(500).json({
        status: "error",
        message: `Gagal membaca file hasil: ${filePath} (${e.code || e.message})`,
      });
    }
  });
}

app.get("/api/:type", (req, res) => {
  handleAccount(req, res).catch((err) => {
    console.error("Unhandled error:", err);
    res.status(500).json({ status: "error", message: "Kesalahan tak terduga." });
  });
});

app.listen(PORT, () => {
  console.log(`API jalan di http://localhost:${PORT}`);
});
