import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import fetch from 'node-fetch';
import crypto from 'crypto';
import QRCode from 'qrcode';
import sharp from 'sharp';
import sqlite3pkg from 'sqlite3';
import { fileURLToPath } from 'url';
import { createWriteStream } from 'fs';
import { pipeline } from 'stream';
import { promisify } from 'util';
const streamPipeline = promisify(pipeline);

import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

dotenv.config();
const JWT_SECRET = process.env.JWT_SECRET || 'devsecret';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 8000;

const ADMIN_NUMBER   = process.env.ADMIN_NUMBER || '';
const ORIGIN         = process.env.ALLOW_ORIGIN || '';
const PAY_API_BASE   = process.env.PAY_API_BASE || '';
const PAY_API_KEY    = process.env.PAY_API_KEY  || '';
const PAY_MERCHANT   = process.env.PAY_MERCHANT || '';
const qrisStatis     = process.env.QR_STRING    || '';
const EXT_API_KEY    = process.env.EXT_API_KEY  || '';
const QR_BASE        = "http://localhost:8000/qrcode";
const DB_PATH        = path.join(__dirname, 'data', 'vpnku.db');
const AMOUNT_TOLERANCE = Number(process.env.PAY_AMOUNT_TOLERANCE || 0);
const POLL_INTERVAL_MS = Number(process.env.POLL_INTERVAL_MS || 5000);
const POLL_ORDER_WINDOW_MIN = Number(process.env.POLL_ORDER_WINDOW_MIN || 120);

const PLANS_PATH = path.join(__dirname, 'data', 'plans.json');

const toRupiah = n => Number(n || 0).toLocaleString('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });
const generateKodeUnik = (min = 1, max = 99) => Math.floor(Math.random() * (max - min + 1)) + min;
const toInt = (str) => Number(String(str).replace(/[^\d]/g, '')) || 0;

function ConvertCRC16(str) {
  let crc = 0xFFFF;
  for (let c = 0; c < str.length; c++) {
    crc ^= str.charCodeAt(c) << 8;
    for (let i = 0; i < 8; i++) {
      if ((crc & 0x8000) !== 0) {
        crc = (crc << 1) ^ 0x1021;
      } else {
        crc <<= 1;
      }
    }
  }
  let hex = (crc & 0xFFFF).toString(16).toUpperCase();
  return hex.padStart(4, '0');
}

function convertQris(qris, nominal) {
  qris = qris.slice(0, -4);
  let step1 = qris.replace("010211", "010212");
  let step2 = step1.split("5802ID");

  let uang = "54" + nominal.length.toString().padStart(2, '0') + nominal;
  uang += "5802ID";

  let hasil = step2[0] + uang + step2[1];
  hasil += ConvertCRC16(hasil);

  return hasil;
}

async function generateQRWithLogoBuffer(data, logoPath) {
  const qrBuffer = await QRCode.toBuffer(data, {
    width: 512,
    margin: 4,
    errorCorrectionLevel: 'H'
  });

  const logoBuffer = await sharp(logoPath)
    .resize(100, 100)
    .toBuffer();

  const finalBuffer = await sharp(qrBuffer)
    .composite([{ input: logoBuffer, gravity: 'center' }])
    .png()
    .toBuffer();

  return finalBuffer;
}

async function generateVoucherQRBuffer(text, logoPath) {
  const qrBuffer = await QRCode.toBuffer(text, {
    width: 512,
    margin: 4,
    errorCorrectionLevel: 'H'
  });

  const logoBuffer = await sharp(logoPath)
    .resize(100, 100)
    .toBuffer();

  const finalBuffer = await sharp(qrBuffer)
    .composite([{ input: logoBuffer, gravity: 'center' }])
    .png()
    .toBuffer();

  return finalBuffer;
}

function normalizeWa(wa) {
  let s = String(wa || '').replace(/\D/g, '');
  if (!s) return s;
  if (s.startsWith('0')) s = '62' + s.slice(1);
  if (!s.startsWith('62')) s = '62' + s;
  return s;
}

function hitungDraft(base, bulan) {
  const subtotal = base * bulan;
  const diskon = bulan >= 12 ? Math.round(subtotal * 0.15)
            : bulan >= 3  ? Math.round(subtotal * 0.05)
            : 0;
  const totalDraft = subtotal - diskon;
  return { subtotal, diskon, totalDraft };
}

function parseJkt(dateStr) {
  if (!dateStr || typeof dateStr !== 'string' || !dateStr.includes(' ')) return new Date(NaN);
  const [d, t] = dateStr.trim().split(' ');
  const [Y, M, D] = d.split('-').map(Number);
  const [h, m] = t.split(':').map(Number);
  const utcMs = Date.UTC(Y, M - 1, D, h - 7, m, 0, 0);
  return new Date(utcMs);
}

function daysFromMonths(bulan) {
  const b = Number(bulan || 1);
  return b > 0 ? b * 30 : 30;
}

function formatBandwidth(n) {
  const val = Number(n) || 0;
  if (val >= 1000) return (val / 1000) + ' TB';
  return val + ' GB';
}

function decrementPlanStock(planId) {
  try {
    const plans = JSON.parse(fs.readFileSync(PLANS_PATH, 'utf8'));
    const i = plans.findIndex(p => p.id === planId);
    if (i === -1) return;

    const cur = plans[i];
    const s = Number(cur?.stock);

    if (!Number.isFinite(s)) return;

    if (s > 0) {
      cur.stock = s - 1;
      if (cur.stock < 0) cur.stock = 0;
      fs.writeFileSync(PLANS_PATH, JSON.stringify(plans, null, 2));
      // console.log(`[stock] ${planId}: ${s} -> ${cur.stock}`);
    }
  } catch (e) {
    console.error('decrementPlanStock error:', e);
  }
}

async function settleOrderWithTxCandidate(orderId, tx, planIdToDec) {
  const issuerRef = tx.issuer_reff ? String(tx.issuer_reff) : null;
  const buyerRef  = tx.buyer_reff  ? String(tx.buyer_reff)  : null;
  const providerRef = issuerRef || buyerRef || `${tx.brand_name || ''}-${tx.date}-${tx.amount}`;

  await new Promise((resolve, reject) => {
    db.serialize(() => {
      db.run('BEGIN IMMEDIATE TRANSACTION;', [], (err) => {
        if (err) return reject(err);

        db.get(`SELECT paid FROM orders WHERE id=?`, [orderId], (e2, row) => {
          if (e2) { db.run('ROLLBACK;', [], () => reject(e2)); return; }
          if (row?.paid) { db.run('COMMIT;', [], () => resolve()); return; }

          const insertPay = `INSERT OR IGNORE INTO payments
            (order_id, provider_ref, issuer_reff, buyer_reff, amount, date_iso, raw_json, created_at)
            VALUES (?,?,?,?,?,?,?,?)`;

          db.run(
            insertPay,
            [
              orderId,
              providerRef,
              issuerRef,
              buyerRef,
              toInt(tx.amount),
              new Date(parseJkt(tx.date)).toISOString(),
              JSON.stringify(tx),
              Date.now()
            ],
            (e3) => {
              if (e3) { db.run('ROLLBACK;', [], () => reject(e3)); return; }
              try { decrementPlanStock(planIdToDec); } catch {}
              db.run(`UPDATE orders SET paid=1 WHERE id=?`, [orderId], (e4) => {
                if (e4) { db.run('ROLLBACK;', [], () => reject(e4)); return; }
                db.run('COMMIT;', [], (e5) => e5 ? reject(e5) : resolve());
              });
            }
          );
        });
      });
    });
  });
}

async function fetchProviderMutations() {
  if (!PAY_API_KEY || !PAY_MERCHANT) throw new Error('PAY_API_KEY / PAY_MERCHANT belum diset');
  const url = new URL(PAY_API_BASE);
  url.searchParams.set('key', PAY_API_KEY);
  url.searchParams.set('merchant', PAY_MERCHANT);
  const r = await fetch(url.toString(), { method: 'GET', headers: { 'Accept': 'application/json' } });
  if (!r.ok) {
    const text = await r.text().catch(() => '');
    throw new Error(`Gagal panggil API mutasi: ${r.status} ${text.slice(0,200)}`);
  }
  const j = await r.json();
  return Array.isArray(j?.data) ? j.data : [];
}

function matchTxForOrder(txList, order) {
  const expected = Number(order.total);
  const since = new Date(order.since_iso);
  const sinceWithSkew = new Date(since.getTime() - 10 * 60 * 1000);
  const candidates = txList.filter(tx => {
    const isCredit = String(tx?.type).toUpperCase() === 'CR';
    const amt = toInt(tx?.amount);
    const when = parseJkt(String(tx?.date || ''));
    const amtOk = Math.abs(amt - expected) <= AMOUNT_TOLERANCE;
    return isCredit && amtOk && when >= sinceWithSkew && !isNaN(when.getTime());
  });
  if (candidates.length === 0) return null;
  return candidates.sort((a,b) => parseJkt(b.date) - parseJkt(a.date))[0];
}

async function pollPaymentsWorker() {
  try {
    const cutoffMs = Date.now() - POLL_ORDER_WINDOW_MIN * 60 * 1000;
    const unpaid = await dbAll(
      `SELECT id, total, since_iso, plan_id FROM orders
       WHERE paid=0 AND created_at >= ? LIMIT 500`, [cutoffMs]
    );
    if (unpaid.length === 0) return;
    const txList = await fetchProviderMutations();
    for (const o of unpaid) {
      const tx = matchTxForOrder(txList, o);
      if (!tx) continue;
      await settleOrderWithTxCandidate(o.id, tx, o.plan_id);
    }
  } catch (e) {
    console.error('[pollPaymentsWorker]', e?.message || e);
  }
}

function escapeHtml(s) {
  return String(s || '')
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;');
}

function htmlMsg(title, body) {
  return `<!doctype html><meta charset="utf-8">
<title>${escapeHtml(title)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<style>body{font-family:Inter,system-ui;-webkit-font-smoothing:antialiased;margin:40px;color:#0f172a}pre{white-space:pre-wrap}</style>
<h1 style="font-size:20px;margin:0 0 10px">${escapeHtml(title)}</h1>
<div style="color:#475569">${body}</div>`;
}

function renderCredsPage({ order: o, cred }) {
  const protocol = (cred.protocol || o.protocol || '').toUpperCase();
  const expDays = cred.exp_days || daysFromMonths(o.bulan);
  const payload = cred.payload || '';
  const admin = ADMIN_NUMBER || '';

  return `<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Informasi Akun • VPNku</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          fontFamily: { sans: ["Inter","system-ui","-apple-system","Segoe UI","Roboto","Helvetica Neue","Arial"] }
        }
      }
    }
  </script>
  <style>
    :root { color-scheme: light dark; }
    body { font-family:'Inter',system-ui,-apple-system,Segoe UI,Roboto,"Helvetica Neue",Arial }
    pre{white-space:pre-wrap;word-wrap:break-word;}
  </style>
</head>
<body class="bg-gradient-to-b from-slate-50 to-white text-slate-800 min-h-screen
             dark:from-slate-900 dark:to-slate-950 dark:text-slate-100">
  <header class="sticky top-0 z-40 backdrop-blur supports-[backdrop-filter]:bg-white/70 border-b border-slate-200/70
                 bg-white/70 dark:bg-slate-900/70 dark:border-slate-700">
    <div class="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
      <div class="flex h-16 items-center justify-between">
        <a href="/" class="flex items-center gap-3 group">
          <span class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-slate-900 text-white shadow-sm">⚡</span>
          <span class="text-lg font-bold tracking-tight">VPNku</span>
        </a>
        <div class="flex items-center gap-3">
          <div class="text-sm text-slate-500 dark:text-slate-400">
            Order <span class="font-semibold">${o.id.slice(0,8)}</span> • ${protocol}
          </div>
          <button id="themeToggle"
                  class="rounded-xl border border-slate-300 px-3 py-1.5 text-sm hover:bg-slate-50
                         dark:border-slate-600 dark:hover:bg-slate-800"
                  aria-label="Ganti tema">🌗</button>
        </div>
      </div>
    </div>
  </header>

  <main class="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-10">
    <div class="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm
                dark:border-slate-700 dark:bg-slate-900">
      <h1 class="text-xl font-bold text-slate-900 dark:text-white">Informasi Akun</h1>
      <p class="mt-1 text-slate-600 dark:text-slate-400">Silahkan Salin atau Unduh Informasi akun Anda.</p>

      <div class="mt-4 flex items-center gap-3">
        <button id="saveBtn" class="rounded-xl border border-slate-300 px-3.5 py-2 text-sm hover:bg-white
                           dark:border-slate-600 dark:hover:bg-slate-800">Unduh .txt</button>
        <a href="/" class="rounded-xl border border-slate-300 px-3.5 py-2 text-sm hover:bg-white
                           dark:border-slate-600 dark:hover:bg-slate-800">Kembali ke Beranda</a>
      </div>

      <pre id="out" class="mt-4 p-4 bg-slate-50 rounded-2xl border border-slate-200 text-sm
                           text-slate-800 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-100">${escapeHtml(payload)}</pre>

      <div class="mt-6 text-sm">
        <a class="underline text-slate-700 dark:text-slate-300" target="_blank"
           href="https://wa.me/${admin}?text=${encodeURIComponent('Halo Admin, order '+o.id+' sudah dibayar.')}">Chat Admin</a>
      </div>
    </div>
  </main>

  <script>
    (function(){
      const STORAGE_KEY = "vpnku-theme";
      const root = document.documentElement;
      const btn  = document.getElementById("themeToggle");

      const initial = localStorage.getItem(STORAGE_KEY)
        || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
      if (initial === "dark") root.classList.add("dark");

      const apply = (mode) => {
        if (mode === "dark") { root.classList.add("dark");  localStorage.setItem(STORAGE_KEY,"dark"); }
        else                 { root.classList.remove("dark"); localStorage.setItem(STORAGE_KEY,"light"); }
      };

      btn?.addEventListener("click", () => {
        apply(root.classList.contains("dark") ? "light" : "dark");
      });

      matchMedia("(prefers-color-scheme: dark)").addEventListener("change", (e) => {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) return;
        apply(e.matches ? "dark" : "light");
      });
    })();
  </script>

  <script>
    (function(){
      const out = document.getElementById('out');
      const saveBtn = document.getElementById('saveBtn');

      saveBtn?.addEventListener('click', () => {
        const blob = new Blob([out.textContent || ''], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'akun-${protocol.toLowerCase()}-${o.nama}.txt';
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(()=>URL.revokeObjectURL(url), 1000);
      });
    })();
  </script>
</body>
</html>
`;
}

app.use(cors({ origin: ORIGIN }));
app.use(express.json());
app.use('/data', express.static(path.join(__dirname, 'data')));
app.use('/qris', express.static(path.join(__dirname, 'qris')));
app.use('/', express.static(path.join(__dirname, 'public')));

fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
fs.mkdirSync(path.join(__dirname, 'qris'), { recursive: true });

const sqlite3 = sqlite3pkg.verbose();
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new sqlite3.Database(DB_PATH);
db.serialize(() => {
  db.run(`PRAGMA journal_mode = DELETE;`);
  db.run(`PRAGMA synchronous = NORMAL;`);
  db.run(`PRAGMA busy_timeout = 3000;`);

  db.run(`CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    nama TEXT NOT NULL,
    wa TEXT NOT NULL,
    plan_id TEXT NOT NULL,
    bulan INTEGER NOT NULL,
    protocol TEXT,
    base_price INTEGER NOT NULL,
    diskon INTEGER NOT NULL,
    kode_unik INTEGER NOT NULL,
    total INTEGER NOT NULL,
    since_iso TEXT NOT NULL,
    paid INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    device INTEGER,
    bandwidth INTEGER
  );`);

  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    wa TEXT NOT NULL UNIQUE,
    nama TEXT,
    pass_hash TEXT NOT NULL,
    is_admin INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
  );`);

  db.run(`CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id TEXT NOT NULL,
    provider_ref TEXT,
    issuer_reff TEXT,
    buyer_reff  TEXT,
    amount INTEGER NOT NULL,
    date_iso TEXT NOT NULL,
    raw_json TEXT,
    created_at INTEGER NOT NULL,
    UNIQUE(provider_ref),
    FOREIGN KEY(order_id) REFERENCES orders(id)
  );`);

  db.run(`CREATE TABLE IF NOT EXISTS creds (
    order_id  TEXT PRIMARY KEY,
    protocol  TEXT,
    username  TEXT,
    exp_days  INTEGER,
    quota     INTEGER,
    iplimit   INTEGER,
    payload   TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    FOREIGN KEY(order_id) REFERENCES orders(id)
  );`);

  db.run(`CREATE TABLE IF NOT EXISTS wallets (
    wa TEXT PRIMARY KEY,
    balance INTEGER NOT NULL DEFAULT 0,
    updated_at INTEGER NOT NULL
  );`);

  db.run(`CREATE TABLE IF NOT EXISTS wallet_tx (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    wa TEXT NOT NULL,
    amount INTEGER NOT NULL,
    note TEXT,
    created_at INTEGER NOT NULL,
    FOREIGN KEY(wa) REFERENCES wallets(wa)
  );`);

  db.run(`CREATE INDEX IF NOT EXISTS idx_orders_paid ON orders(paid);`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_payments_order ON payments(order_id);`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_wallet_tx_wa ON wallet_tx(wa);`);

  db.run(`ALTER TABLE users ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0`, () => {});
  db.run(`ALTER TABLE orders ADD COLUMN device INTEGER`,   () => {});
  db.run(`ALTER TABLE orders ADD COLUMN bandwidth INTEGER`,() => {});
  db.run(`ALTER TABLE orders ADD COLUMN protocol TEXT`, () => {});
  db.run(`ALTER TABLE payments ADD COLUMN issuer_reff TEXT`, () => {});
  db.run(`ALTER TABLE payments ADD COLUMN buyer_reff  TEXT`, () => {});
});

function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => db.get(sql, params, (e, row) => e ? reject(e) : resolve(row)));
}
function dbAll(sql, params = []) {
  return new Promise((resolve, reject) => db.all(sql, params, (e, rows) => e ? reject(e) : resolve(rows)));
}
function dbRun(sql, params = []) {
  return new Promise((resolve, reject) => db.run(sql, params, function (e) { e ? reject(e) : resolve(this); }));
}

async function downloadQR(orderId, harga) {
  const remoteUrl = `${QR_BASE}?id=${encodeURIComponent(orderId)}&harga=${encodeURIComponent(harga)}`;
  const localFile = path.join(__dirname, 'qris', `qr-${orderId}.png`);
  const response = await fetch(remoteUrl);
  if (!response.ok) throw new Error(`Gagal fetch QR: ${response.statusText}`);
  await streamPipeline(response.body, createWriteStream(localFile));
  return `/qris/qr-${orderId}.png`;
}

async function ensureWallet(wa) {
  const W = normalizeWa(wa);
  let w = await dbGet(`SELECT wa, balance FROM wallets WHERE wa=?`, [W]);
  if (!w) {
    await dbRun(`INSERT INTO wallets (wa, balance, updated_at) VALUES (?,?,?)`, [W, 0, Date.now()]);
    w = { wa: W, balance: 0 };
  }
  return w;
}

app.get("/qrcode", async (req, res) => {
  const id = req.query.id;
  const harga = req.query.harga;

  if (!id || !harga) {
    return res.status(400).json({ error: "Parameter id dan harga wajib diisi" });
  }

  try {
    const qrisDinamis = convertQris(qrisStatis, harga.trim());

    const logoPath = path.join(__dirname, 'qris', 'logo.png');
    if (!fs.existsSync(logoPath)) {
      return res.status(500).json({ error: "Logo tidak ditemukan di server" });
    }

    const resultBuffer = await generateQRWithLogoBuffer(qrisDinamis, logoPath);

    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Content-Disposition', `inline; filename="qris-${id}.png"`);
    res.send(resultBuffer);
  } catch (err) {
    res.status(500).json({ error: "Gagal generate QR" });
  }
});

app.get('/api/plans', async (req, res) => {
  try {
    const p = JSON.parse(fs.readFileSync(PLANS_PATH, 'utf8'));
    res.json(p);
  } catch {
    res.status(500).json({ error: 'Gagal baca plans' });
  }
});

app.post('/api/orders/draft', async (req, res) => {
  try {
    const { planId, bulan = 1 } = req.body || {};
    if (!planId) return res.status(400).json({ error: 'planId wajib' });

    const plans = JSON.parse(fs.readFileSync(PLANS_PATH, 'utf8'));
    const plan = plans.find(p => p.id === planId);
    if (!plan) return res.status(404).json({ error: 'Plan tidak ditemukan' });

    const nBulan = Number(bulan);
    if (!Number.isFinite(nBulan) || nBulan <= 0) return res.status(400).json({ error: 'bulan tidak valid' });

    const { subtotal, diskon, totalDraft } = hitungDraft(plan.harga, nBulan);

    res.json({
      ok: true,
      plan: plan.nama,
      subtotal,
      diskon,
      total: totalDraft,
      labelTotal: toRupiah(totalDraft),
      note: 'Ini hanya draft, belum disimpan. Kode unik akan ditambahkan saat pembayaran.'
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Gagal membuat draft (hitung)' });
  }
});

app.post('/api/payments/create', async (req, res) => {
  try {
    const { orderId, nama, wa, planId, bulan = 1, protocol, device, bandwidth } = req.body || {};

    if (orderId) {
      if (!nama || !wa) return res.status(400).json({ error: 'nama & wa wajib' });

      const order = await dbGet(`SELECT * FROM orders WHERE id = ?`, [orderId]);
      if (!order) return res.status(404).json({ error: 'Order tidak ditemukan' });

      const W = normalizeWa(wa);

      let newBulan = Number(bulan || order.bulan);
      if (!Number.isFinite(newBulan) || newBulan <= 0) newBulan = order.bulan;
      let newProtocol = protocol ? String(protocol).toLowerCase() : order.protocol;

      const plansAll = JSON.parse(fs.readFileSync(PLANS_PATH, 'utf8'));
      const planForOrder = plansAll.find(p => p.id === order.plan_id);
      const base_price = planForOrder ? planForOrder.harga : order.base_price;

      const bodyDev = Number(device);
      const bodyBw  = Number(bandwidth);
      const newDevice    = Number.isFinite(bodyDev) ? bodyDev
                          : Number.isFinite(order.device) ? Number(order.device)
                          : Number(planForOrder?.device || 0);
      const newBandwidth = Number.isFinite(bodyBw) ? bodyBw
                          : Number.isFinite(order.bandwidth) ? Number(order.bandwidth)
                          : Number(planForOrder?.bandwidth || 0);

      const { subtotal, diskon } = hitungDraft(base_price, newBulan);

      let kode_unik = Number(order.kode_unik || 0);
      if (!kode_unik || kode_unik <= 0) {
        kode_unik = generateKodeUnik(1, 99);
      }

      const total = subtotal - diskon + kode_unik;

      await dbRun(
        `UPDATE orders
           SET nama = ?, wa = ?, bulan = ?, protocol = ?, base_price = ?, diskon = ?, kode_unik = ?, total = ?, device = ?, bandwidth = ?
         WHERE id = ?`,
        [nama, W, newBulan, newProtocol || null, base_price, diskon, kode_unik, total, newDevice, newBandwidth, orderId]
      );

      const qrLocalPath = await downloadQR(orderId, total);
      const paymentUrl = `${req.protocol}://${req.get('host')}/pay/${encodeURIComponent(orderId)}`;

      return res.json({
        ok: true,
        orderId,
        amount: total,
        since: order.since_iso,
        summary: {
          plan: planForOrder?.nama ?? order.plan_id,
          subtotal,
          diskon,
          kodeUnik: kode_unik,
          total,
          labelTotal: toRupiah(total),
          protocol: newProtocol || null,
          bulan: newBulan,
          device: newDevice,
          bandwidth: newBandwidth
        },
        qr: { title: 'Scan untuk bayar', image: qrLocalPath },
        paymentUrl
      });
    }

    if (!nama || !wa || !planId) return res.status(400).json({ error: 'nama, wa, planId wajib' });

    const plans = JSON.parse(fs.readFileSync(PLANS_PATH, 'utf8'));
    const plan = plans.find(p => p.id === planId);
    if (!plan) return res.status(404).json({ error: 'Plan tidak ditemukan' });

    {
      const s = Number(plan.stock);
      if (Number.isFinite(s) && s < 1) {
        return res.status(400).json({ error: 'Stok paket habis' });
      }
    }

    const nBulan = Number(bulan);
    if (!Number.isFinite(nBulan) || nBulan <= 0) return res.status(400).json({ error: 'bulan tidak valid' });

    const { subtotal, diskon, totalDraft } = hitungDraft(plan.harga, nBulan);

    const kodeUnik = generateKodeUnik(1, 99);
    const total = totalDraft + kodeUnik;

    const id = crypto.randomUUID();
    const sinceISO = new Date().toISOString();
    const createdAt = Date.now();
    const W = normalizeWa(wa);
    const P = protocol ? String(protocol).toLowerCase() : null;

    const nDevice    = Number.isFinite(Number(device))    ? Number(device)    : Number(plan.device || 0);
    const nBandwidth = Number.isFinite(Number(bandwidth)) ? Number(bandwidth) : Number(plan.bandwidth || 0);

    await dbRun(
      `INSERT INTO orders
       (id, nama, wa, plan_id, bulan, protocol, base_price, diskon, kode_unik, total, since_iso, paid, created_at, device, bandwidth)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?)`,
      [id, nama, W, planId, nBulan, P, plan.harga, diskon, kodeUnik, total, sinceISO, createdAt, nDevice, nBandwidth]
    );

    const qrLocalPath = await downloadQR(id, total);
    const paymentUrl = `${req.protocol}://${req.get('host')}/pay/${encodeURIComponent(id)}`;

    return res.json({
      ok: true,
      orderId: id,
      amount: total,
      since: sinceISO,
      summary: {
        plan: plan.nama,
        subtotal,
        diskon,
        kodeUnik,
        total,
        labelTotal: toRupiah(total),
        protocol: P,
        bulan: nBulan,
        device: nDevice,
        bandwidth: nBandwidth
      },
      qr: { title: 'Scan untuk bayar', image: qrLocalPath },
      paymentUrl
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Gagal membuat order' });
  }
});

app.get('/api/orders/:id/status', async (req, res) => {
  try {
    const id = req.params.id;
    const o = await dbGet(`SELECT id, total, since_iso, paid FROM orders WHERE id=?`, [id]);
    if (!o) return res.status(404).json({ error: 'Order tidak ditemukan' });

    let lastPay = null;
    if (o.paid) {
      lastPay = await dbGet(
        `SELECT provider_ref, issuer_reff, buyer_reff, amount, date_iso
         FROM payments WHERE order_id=? ORDER BY id DESC LIMIT 1`, [id]
      );
    }

    res.json({
      ok: true,
      orderId: o.id,
      paid: Number(o.paid) === 1,
      expectedAmount: o.total,
      since: o.since_iso,
      lastPayment: lastPay ? {
        amount: lastPay.amount,
        date: lastPay.date_iso,
        provider_reff: lastPay.provider_ref,
        issuer_reff: lastPay.issuer_reff,
        buyer_reff:  lastPay.buyer_reff
      } : null,
      checkedAt: new Date().toISOString()
    });
  } catch (e) {
    res.status(500).json({ error: 'Gagal ambil status', detail: String(e?.message || e) });
  }
});

function requireAuth(req, res, next) {
  const h = req.headers['authorization'] || '';
  const m = h.match(/^Bearer\s+(.+)$/i);
  if (!m) return res.status(401).json({ error: 'Token tidak ada' });
  try {
    req.user = jwt.verify(m[1], JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'Token tidak valid' });
  }
}

function requireAdmin(req, res, next) {
  requireAuth(req, res, () => {
    if (Number(req.user?.is_admin) === 1) return next();
    return res.status(403).json({ error: 'Admin only' });
  });
}

app.post('/api/auth/register', async (req, res) => {
  try {
    const { wa, password, nama } = req.body || {};
    if (!wa || !password) return res.status(400).json({ error: 'WA dan password wajib' });
    const W = normalizeWa(wa);
    const hash = await bcrypt.hash(String(password), 10);
    const now = Date.now();
    db.run(`INSERT INTO users (wa, nama, pass_hash, is_admin, created_at) VALUES (?,?,?,?,?)`,
      [W, nama || '', hash, 1, now],
      function(err){
        if (err) {
          if (String(err.message||'').includes('UNIQUE')) return res.status(409).json({ error: 'Nomor WA sudah terdaftar' });
          return res.status(500).json({ error: 'DB error' });
        }
        const uid = this.lastID;
        const token = jwt.sign({ uid, wa: W, nama: nama || '', is_admin: 0 }, JWT_SECRET, { expiresIn: '30d' });
        res.json({ ok: true, token, user: { uid, wa: W, nama: nama || '', is_admin: 0 } });
      });
  } catch (e) {
    res.status(500).json({ error: 'Gagal register' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { wa, password } = req.body || {};
    if (!wa || !password) return res.status(400).json({ error: 'WA dan password wajib' });
    const W = normalizeWa(wa);
    db.get(`SELECT id, wa, nama, pass_hash, is_admin FROM users WHERE wa=?`, [W], async (err, row) => {
      if (err) return res.status(500).json({ error: 'DB error' });
      if (!row) return res.status(400).json({ error: 'Akun tidak ditemukan' });
      const ok = await bcrypt.compare(String(password), row.pass_hash);
      if (!ok) return res.status(401).json({ error: 'Password salah' });
      const token = jwt.sign({ uid: row.id, wa: row.wa, nama: row.nama || '', is_admin: Number(row.is_admin)||0 }, JWT_SECRET, { expiresIn: '30d' });
      res.json({ ok: true, token, user: { uid: row.id, wa: row.wa, nama: row.nama || '', is_admin: Number(row.is_admin)||0 } });
    });
  } catch (e) {
    res.status(500).json({ error: 'Gagal login' });
  }
});

app.get('/api/auth/me', requireAuth, (req, res) => {
  res.json({ user: req.user });
});

app.get('/api/orders/my', requireAuth, async (req, res) => {
  try {
    const W = req.user.wa;
    const rows = await dbAll(
      `SELECT id, nama, wa, plan_id, bulan, protocol, total, created_at, paid
       FROM orders WHERE wa=? ORDER BY created_at DESC LIMIT 200`, [W]
    );
    res.json({ orders: rows || [] });
  } catch {
    res.status(500).json({ error: 'DB error' });
  }
});

app.post('/api/orders/:id/finalize', async (req, res) => {
  try {
    const order = await dbGet(`SELECT * FROM orders WHERE id = ?`, [req.params.id]);
    if (!order) return res.status(404).json({ error: 'Order tidak ditemukan' });
    if (!order.paid) return res.status(400).json({ error: 'Belum terverifikasi bayar' });

    const dataConfirm = `Username: ${order.nama}
Whatsapp: ${normalizeWa(order.wa)}
Server: ${order.plan_id}
Protokol: ${order.protocol || '-'}
Durasi: ${order.bulan} Bulan
Harga : ${order.total}
No.Transaksi: ${order.id}`;

    res.json({
      ok: true,
      message: 'Akun akan dikirim via WhatsApp',
      waLink: `https://wa.me/${ADMIN_NUMBER}?text=${encodeURIComponent('Halo, Saya ingin konfirmasi Pembelian VPN:\n\n' + dataConfirm)}`
    });
  } catch (e) {
    res.status(500).json({ error: 'Gagal finalize', detail: String(e?.message || e) });
  }
});

app.get('/pay/:orderId', async (req, res) => {
  const o = await dbGet(`SELECT * FROM orders WHERE id = ?`, [req.params.orderId]);
  if (!o) {
    return res.redirect("/");
  }
  const amountLabel = toRupiah(o.total);
  const qrLocalPath = await downloadQR(o.id, o.total);
  const expireMs = o.created_at + 10 * 60 * 1000;

  res.send(`<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Bayar Pesanan • VPNku</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          fontFamily: { sans: ["Inter","system-ui","-apple-system","Segoe UI","Roboto","Helvetica Neue","Arial"] }
        }
      }
    }
  </script>
  <style>
    :root { color-scheme: light dark; }
    body{font-family:'Inter',system-ui,-apple-system,Segoe UI,Roboto,"Helvetica Neue",Arial}
  </style>
</head>
<body class="bg-gradient-to-b from-slate-50 to-white text-slate-800 min-h-screen
             dark:from-slate-900 dark:to-slate-950 dark:text-slate-100">
  <header class="sticky top-0 z-40 backdrop-blur supports-[backdrop-filter]:bg-white/70 border-b border-slate-200/70
                 bg-white/70 dark:bg-slate-900/70 dark:border-slate-700">
    <div class="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
      <div class="flex h-16 items-center justify-between">
        <a href="/" class="flex items-center gap-3 group">
          <span class="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-slate-900 text-white shadow-sm">⚡</span>
          <span class="text-lg font-bold tracking-tight">VPNku</span>
        </a>
        <div class="flex items-center gap-3">
          <div class="text-sm text-slate-500 dark:text-slate-400">
            Order <span class="font-semibold">${o.id.slice(0,8)}</span>
          </div>
          <button id="themeToggle"
                  class="rounded-xl border border-slate-300 px-3 py-1.5 text-sm hover:bg-slate-50
                         dark:border-slate-600 dark:hover:bg-slate-800"
                  aria-label="Ganti tema">🌗</button>
        </div>
      </div>
    </div>
  </header>

  <main class="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-10">
    <div class="grid gap-8 md:grid-cols-2">
      <div class="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm
                  dark:border-slate-700 dark:bg-slate-900">
        <h1 class="text-xl font-bold text-slate-900 dark:text-white">Selesaikan Pembayaran</h1>
        <p class="mt-1 text-slate-600 dark:text-slate-400">Scan QR di bawah dengan aplikasi bank / e-wallet.</p>
        <div class="mt-6 grid place-items-center">
          <img id="qrimg" src="${qrLocalPath}" alt="QR Pembayaran"
               class="w-64 h-64 rounded-xl border border-slate-200 object-contain bg-white
                      dark:border-slate-700 dark:bg-slate-800"/>
        </div>
        <div class="mt-5 text-center">
          <div class="text-sm text-slate-600 dark:text-slate-400">Total bayar</div>
          <div class="mt-1 text-3xl font-extrabold text-slate-900 dark:text-white">${amountLabel}</div>
          <button id="refreshBtn"
                  class="mt-3 inline-flex items-center gap-2 rounded-xl border border-slate-300 px-3.5 py-2 text-sm hover:bg-white
                         disabled:opacity-60 disabled:cursor-not-allowed
                         dark:border-slate-600 dark:hover:bg-slate-800">
            <span class="inline-block">Refresh status</span>
          </button>
          <div class="mt-3 text-sm text-slate-500 dark:text-slate-400">Batas waktu: <span id="countdown" class="font-semibold">—</span></div>
        </div>
      </div>

      <aside class="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm
                    dark:border-slate-700 dark:bg-slate-900">
        <h2 class="text-lg font-semibold text-slate-900 dark:text-white">Detail Pesanan</h2>
        <dl class="mt-4 space-y-2 text-sm text-slate-700 dark:text-slate-300">
          <div class="flex items-center justify-between"><dt>Nama</dt><dd class="font-medium text-slate-900 dark:text-white">${o.nama}</dd></div>
          <div class="flex items-center justify-between"><dt>WhatsApp</dt><dd class="font-medium text-slate-900 dark:text-white">${normalizeWa(o.wa)}</dd></div>
          <div class="flex items-center justify-between"><dt>Durasi</dt><dd class="font-medium text-slate-900 dark:text-white">${o.bulan} bulan</dd></div>
          <div class="flex items-center justify-between"><dt>Protokol</dt><dd class="font-medium text-slate-900 dark:text-white">${o.protocol || '-'}</dd></div>
          <div class="flex items-center justify-between"><dt>Bandwidth</dt><dd class="font-medium text-slate-900 dark:text-white">${formatBandwidth(o.bandwidth)}</dd></div>
          <div class="flex items-center justify-between"><dt>Perangkat</dt><dd class="font-medium text-slate-900 dark:text-white">${o.device ?? '-'} device</dd></div>
          <div class="flex items-center justify-between"><dt>Tanggal</dt><dd>${new Date(o.created_at).toLocaleString('id-ID')}</dd></div>
        </dl>

        <div class="mt-6 rounded-2xl bg-slate-50 p-4 text-sm dark:bg-slate-800">
          <div class="flex items-center justify-between text-slate-700 dark:text-slate-300"><span>Subtotal</span><span>${toRupiah(o.base_price * o.bulan)}</span></div>
          <div class="mt-1 flex items-center justify-between text-slate-700 dark:text-slate-300"><span>Diskon</span><span>-${toRupiah(o.diskon)}</span></div>
          <div class="mt-1 flex items-center justify-between text-slate-700 dark:text-slate-300"><span>Kode unik</span><span>${o.kode_unik}</span></div>
          <div class="mt-3 border-t border-slate-200 dark:border-slate-700 pt-3 flex items-center justify-between text-base">
            <span class="font-semibold text-slate-900 dark:text-white">Total</span><span class="font-extrabold text-slate-900 dark:text-white">${amountLabel}</span>
          </div>
        </div>

        <div class="mt-6">
          <div id="status" class="text-sm text-slate-600 dark:text-slate-400">Menunggu pembayaran…</div>
          <button id="backBtn"
                  class="mt-4 inline-flex items-center gap-2 rounded-xl border border-slate-300 px-3.5 py-2 text-sm hover:bg-white
                         dark:border-slate-600 dark:hover:bg-slate-800">Kembali</button>
        </div>
      </aside>
    </div>
  </main>

  <script>
    (function(){
      const STORAGE_KEY = "vpnku-theme";
      const root = document.documentElement;
      const btn  = document.getElementById("themeToggle");

      const initial = localStorage.getItem(STORAGE_KEY)
        || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
      if (initial === "dark") root.classList.add("dark");

      const apply = (mode) => {
        if (mode === "dark") { root.classList.add("dark");  localStorage.setItem(STORAGE_KEY,"dark"); }
        else                 { root.classList.remove("dark"); localStorage.setItem(STORAGE_KEY,"light"); }
      };

      btn?.addEventListener("click", () => {
        apply(root.classList.contains("dark") ? "light" : "dark");
      });

      matchMedia("(prefers-color-scheme: dark)").addEventListener("change", (e) => {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) return;
        apply(e.matches ? "dark" : "light");
      });
    })();
  </script>

  <script>
  (function(){
    const orderId = ${JSON.stringify(o.id)};
    const expireAt = ${o.created_at + 10 * 60 * 1000};
    const statusEl = document.getElementById('status');
    const cdEl = document.getElementById('countdown');
    const refreshBtn = document.getElementById('refreshBtn');
    const backBtn = document.getElementById('backBtn');
    const qrImg = document.getElementById('qrimg');

    const ICON_CHECK = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 24 24" fill="green"><path d="M20.285 6.709l-11.285 11.291-5.285-5.291 1.414-1.416 3.871 3.877 9.871-9.877z"/></svg>';
    const ICON_CROSS = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 24 24" fill="red"><path d="M18.364 5.636l-1.414-1.414L12 9.172 7.05 4.222 5.636 5.636 10.586 10.586 5.636 15.536l1.414 1.414L12 12.828l4.95 4.95 1.414-1.414L13.414 10.586z"/></svg>';

    function tick() {
      const remain = Math.max(0, expireAt - Date.now());
      const mm = String(Math.floor(remain/60000)).padStart(2,'0');
      const ss = String(Math.floor((remain%60000)/1000)).padStart(2,'0');
      cdEl.textContent = mm+':'+ss;
      if (remain <= 0) {
        statusEl.textContent = 'Waktu pembayaran habis. Buat order baru.';
        qrImg.src = ICON_CROSS;
        stopped = true;
        refreshBtn?.setAttribute('disabled', 'disabled');
        clearInterval(cdInt);
      }
    }
    tick();
    const cdInt = setInterval(tick, 1000);

    backBtn?.addEventListener('click', () => { window.location.href = '/'; });

    let stopped = false;
    let inFlight = false;

    function setLoading(loading){
      if (!refreshBtn) return;
      if (loading) {
        refreshBtn.setAttribute('disabled','disabled');
        refreshBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="9" stroke-width="2" opacity="0.25"/><path d="M21 12a9 9 0 0 1-9 9" stroke-width="2"/></svg><span>Memeriksa…</span>';
      } else {
        refreshBtn.removeAttribute('disabled');
        refreshBtn.innerHTML = '<span class="inline-block">Refresh status</span>';
      }
    }

    async function poll(showLoading = false) {
      if (stopped || inFlight) return;
      try {
        inFlight = true;
        if (showLoading) setLoading(true);

        const r = await fetch('/api/orders/' + encodeURIComponent(orderId) + '/status');
        const j = await r.json();
        if (j.ok && j.paid) {
          stopped = true;
          clearInterval(cdInt);
          statusEl.innerHTML = 'Pembayaran <span class="text-green-600 font-semibold">terverifikasi</span>. Membuka Informasi akun...';
          qrImg.src = ICON_CHECK;
          window.location.href = '/order/' + encodeURIComponent(orderId) + '/creds';
          return;
        } else {
          statusEl.textContent = 'Menunggu pembayaran…';
        }

      } catch (e) {
        statusEl.textContent = 'Gagal memeriksa status. Coba lagi.';
      } finally {
        inFlight = false;
        if (showLoading) setLoading(false);
        if (!stopped) setTimeout(() => poll(false), 4000);
      }
    }

    poll(false);
    refreshBtn?.addEventListener('click', () => {
      if (stopped) return;
      statusEl.textContent = 'Memeriksa status pembayaran...';
      poll(true);
    });
  })();
  </script>
</body>
</html>`);
});

app.get('/order/:id/creds', async (req, res) => {
  try {
    const o = await dbGet(`SELECT * FROM orders WHERE id = ?`, [req.params.id]);
    if (!o) {
      return res.redirect("/");
    }
    if (!o.paid) return res.status(403).send(htmlMsg('Belum bayar', 'Pembayaran belum terverifikasi.'));

    const protocol = (o.protocol || '').toLowerCase();
    if (!protocol || !['trojan','vless','vmess'].includes(protocol)) {
      return res.status(400).send(htmlMsg('Protokol tidak valid', 'Protokol tidak ada/invalid.'));
    }

    const plans = JSON.parse(fs.readFileSync(PLANS_PATH, 'utf8'));
    const plan = plans.find(p => p.id === o.plan_id);
    const extApiBase = plan?.ext_api;

    let cred = await dbGet(`SELECT * FROM creds WHERE order_id = ?`, [o.id]);

    if (!cred) {
      const username = String(o.nama || '').trim();
      const expDays  = daysFromMonths(o.bulan);
      const quota    = Number(o.bandwidth) || 0;
      const iplimit  = Number(o.device)    || 0;

      const url = `${extApiBase}/${protocol}` +
        `?key=${EXT_API_KEY}` +
        `&username=${encodeURIComponent(username)}` +
        `&exp=${expDays}` +
        `&quota=${quota}` +
        `&iplimit=${iplimit}`;

      const r = await fetch(url, { method: 'GET' });
      if (!r.ok) {
        const t = await r.text().catch(() => '');
        return res.status(502).send(htmlMsg('Gagal membuat akun', `API eksternal mengembalikan status ${r.status}.<pre class="mt-2 p-3 bg-slate-100 rounded">${escapeHtml(t)}</pre>`));
      }
      const payload = await r.text();
      const now = Date.now();

      await dbRun(
        `INSERT OR IGNORE INTO creds (order_id, protocol, username, exp_days, quota, iplimit, payload, created_at)
         VALUES (?,?,?,?,?,?,?,?)`,
        [o.id, protocol, username, expDays, quota, iplimit, payload, now]
      );
      cred = await dbGet(`SELECT * FROM creds WHERE order_id = ?`, [o.id]);
    }

    res.send(renderCredsPage({ order: o, cred }));
  } catch (e) {
    console.error('creds error', e);
    res.status(500).send(htmlMsg('Gagal', 'Gagal mengambil info Akun.'));
  }
});

app.get('/api/admin/stats', requireAdmin, async (req, res) => {
  try {
    const ordersTotal = await dbGet(`SELECT COUNT(*) AS c FROM orders`);
    const ordersPaid  = await dbGet(`SELECT COUNT(*) AS c FROM orders WHERE paid=1`);
    const revRow      = await dbGet(`SELECT SUM(total) AS s FROM orders WHERE paid=1`);
    const usersTotal  = await dbGet(`SELECT COUNT(*) AS c FROM users`);
    res.json({
      ok: true,
      stats: {
        orders_total: ordersTotal?.c || 0,
        orders_paid: ordersPaid?.c || 0,
        revenue_paid: revRow?.s || 0,
        users_total: usersTotal?.c || 0
      }
    });
  } catch(e){
    res.status(500).json({ error: 'Gagal ambil stats' });
  }
});

app.get('/api/admin/orders', requireAdmin, async (req, res) => {
  try {
    const { q = '', paid = '', page = '1', limit = '20' } = req.query;
    const p = Math.max(1, Number(page)||1);
    const L = Math.min(100, Math.max(1, Number(limit)||20));
    const off = (p-1)*L;
    const where = [];
    const args = [];
    if (q) {
      where.push(`(id LIKE ? OR nama LIKE ? OR wa LIKE ? OR plan_id LIKE ?)`);
      args.push(`%${q}%`,`%${q}%`,`%${q}%`,`%${q}%`);
    }
    if (paid !== '') {
      where.push(`paid = ?`);
      args.push(Number(paid)?1:0);
    }
    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const rows = await dbAll(
      `SELECT id, nama, wa, plan_id, bulan, protocol, total, paid, device, bandwidth, created_at
       FROM orders ${whereSql}
       ORDER BY created_at DESC
       LIMIT ? OFFSET ?`, [...args, L, off]
    );
    const totalRow = await dbGet(`SELECT COUNT(*) AS c FROM orders ${whereSql}`, args);
    res.json({ ok: true, items: rows || [], page: p, limit: L, total: totalRow?.c||0 });
  } catch(e){
    res.status(500).json({ error: 'Gagal ambil orders' });
  }
});

app.patch('/api/admin/orders/:id/mark-paid', requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const row = await dbGet(`SELECT paid, plan_id FROM orders WHERE id=?`, [id]);
    if (!row) return res.status(404).json({ ok:false, error: 'Order tidak ditemukan' });

    if (!row.paid) {
      decrementPlanStock(row.plan_id);
      await dbRun(`UPDATE orders SET paid = 1 WHERE id=?`, [id]);
    }
    res.json({ ok:true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok:false, error: 'Gagal update paid' });
  }
});

app.patch('/api/admin/orders/:id/mark-unpaid', requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const row = await dbGet(`SELECT id FROM orders WHERE id=?`, [id]);
    if (!row) return res.status(404).json({ ok:false, error: 'Order tidak ditemukan' });

    await dbRun(`UPDATE orders SET paid = 0 WHERE id=?`, [id]);
    res.json({ ok:true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok:false, error: 'Gagal update unpaid' });
  }
});

app.delete('/api/admin/orders/:id', requireAdmin, async (req, res) => {
  const id = req.params.id;
  try {
    const o = await dbGet(`SELECT id FROM orders WHERE id=?`, [id]);
    if (!o) return res.status(404).json({ ok:false, error: 'Order tidak ditemukan' });

    await new Promise((resolve, reject) => {
      db.serialize(() => {
        db.run('BEGIN IMMEDIATE;', [], (e)=>{ if(e) return reject(e); });

        db.run(`DELETE FROM payments WHERE order_id=?`, [id], function(e){
          if(e) { db.run('ROLLBACK', [], ()=>reject(e)); return; }

          db.run(`DELETE FROM creds WHERE order_id=?`, [id], function(e2){
            if(e2) { db.run('ROLLBACK', [], ()=>reject(e2)); return; }

            db.run(`DELETE FROM orders WHERE id=?`, [id], function(e3){
              if(e3) { db.run('ROLLBACK', [], ()=>reject(e3)); return; }
              db.run('COMMIT;', [], (e4)=> e4 ? reject(e4) : resolve());
            });
          });
        });
      });
    });

    try {
      const p = path.join(__dirname, 'qris', `qr-${id}.png`);
      if (fs.existsSync(p)) fs.unlinkSync(p);
    } catch {}

    res.json({ ok:true });
  } catch (e) {
    res.status(500).json({ ok:false, error: 'Gagal hapus order', detail: String(e?.message || e) });
  }
});

app.get('/api/admin/plans', requireAdmin, (req, res) => {
  try {
    const p = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'plans.json'), 'utf8'));
    res.json({ ok:true, plans: p });
  } catch {
    res.status(500).json({ error: 'Gagal baca plans' });
  }
});

app.post('/api/admin/plans', requireAdmin, async (req, res) => {
  try {
    const bodyPlans = Array.isArray(req.body?.plans) ? req.body.plans : [];
    const clean = bodyPlans.map(p => {
      const obj = { ...p };
      ['harga','bandwidth','device','stock'].forEach(k => {
        if (obj[k] === '' || obj[k] == null) {
          delete obj[k];
        } else if (typeof obj[k] !== 'number') {
          const n = Number(obj[k]);
          obj[k] = Number.isFinite(n) ? n : undefined;
          if (obj[k] === undefined) delete obj[k];
        }
      });
      return obj;
    });

    fs.writeFileSync(PLANS_PATH, JSON.stringify(clean, null, 2));
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Gagal menyimpan plans' });
  }
});


app.get('/api/admin/account', requireAdmin, async (req, res) => {
  try {
    const row = await dbGet(`SELECT id, wa, nama, is_admin, created_at FROM users WHERE id=?`, [req.user.uid]);
    if (!row) return res.status(404).json({ error: 'Akun tidak ditemukan' });
    res.json({ ok: true, user: row });
  } catch (e) {
    res.status(500).json({ error: 'Gagal ambil akun' });
  }
});

app.patch('/api/admin/account', requireAdmin, async (req, res) => {
  try {
    let { wa, nama, password } = req.body || {};
    const uid = req.user.uid;

    const cur = await dbGet(`SELECT id, wa, nama, is_admin FROM users WHERE id=?`, [uid]);
    if (!cur) return res.status(404).json({ error: 'Akun tidak ditemukan' });

    let newWa = typeof wa === 'string' && wa.trim() ? normalizeWa(wa) : cur.wa;
    let newNama = typeof nama === 'string' ? String(nama).trim() : cur.nama;

    if (!newWa) return res.status(400).json({ error: 'WA tidak boleh kosong' });

    const dup = await dbGet(`SELECT id FROM users WHERE wa = ? AND id <> ?`, [newWa, uid]);
    if (dup) return res.status(409).json({ error: 'Nomor WA sudah dipakai user lain' });

    const sets = ['wa = ?', 'nama = ?'];
    const args = [newWa, newNama];
    if (typeof password === 'string' && password.trim()) {
      if (password.length < 6) return res.status(400).json({ error: 'Password minimal 6 karakter' });
      const hash = await bcrypt.hash(String(password), 10);
      sets.push('pass_hash = ?');
      args.push(hash);
    }
    args.push(uid);

    await dbRun(`UPDATE users SET ${sets.join(', ')} WHERE id = ?`, args);

    const token = jwt.sign(
      { uid, wa: newWa, nama: newNama || '', is_admin: Number(cur.is_admin) || 0 },
      JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.json({
      ok: true,
      token,
      user: { uid, wa: newWa, nama: newNama || '', is_admin: Number(cur.is_admin) || 0 }
    });
  } catch (e) {
    res.status(500).json({ error: 'Gagal update akun', detail: String(e?.message || e) });
  }
});

app.get('/login', (_, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-login.html'));
});

app.get('/admin', (_, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.get('/health', (_, res) => res.json({ ok: true, now: new Date().toISOString(), db: DB_PATH }));

app.use((req, res) => {
  res.redirect('/');
});

setInterval(pollPaymentsWorker, POLL_INTERVAL_MS);

app.listen(PORT, () => {
  console.log(`VPNku listening on :${PORT} (db: ${DB_PATH})`);
});
