(function(){
  const STORAGE_KEY = "vpnku-theme";
  const root = document.documentElement;
  const btn  = document.getElementById("themeToggle");

  const initial = localStorage.getItem(STORAGE_KEY)
    || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  if (initial === "dark") root.classList.add("dark");

  const apply = (mode) => {
    if (mode === "dark") { 
      root.classList.add("dark");  
      localStorage.setItem(STORAGE_KEY,"dark"); 
    } else { 
      root.classList.remove("dark"); 
      localStorage.setItem(STORAGE_KEY,"light"); 
    }
  };

  btn?.addEventListener("click", () => {
    apply(root.classList.contains("dark") ? "light" : "dark");
  });

  matchMedia("(prefers-color-scheme: dark)").addEventListener("change", (e) => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return;
    apply(e.matches ? "dark" : "light");
  });

  const f = document.getElementById('f');
  const msg = document.getElementById('msg');

  function normalizeWaClient(v){
    return (v||'').trim();
  }

  f.addEventListener('submit', async (e)=>{
    e.preventDefault();
    msg.textContent = '';
    const fd = new FormData(f);
    const body = {
      wa: normalizeWaClient(fd.get('wa')),
      password: String(fd.get('password')||'')
    };
    try{
      const r = await fetch('/api/auth/login', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify(body)
      });
      const j = await r.json();
      if(!r.ok){ msg.textContent = j.error || 'Login gagal'; return; }
      if(!j.user || j.user.is_admin !== 1){ msg.textContent = 'Bukan akun admin.'; return; }
      localStorage.setItem('adm_token', j.token);
      window.location.href = '/admin';
    }catch(err){
      msg.textContent = 'Gagal login.';
    }
  });

})();