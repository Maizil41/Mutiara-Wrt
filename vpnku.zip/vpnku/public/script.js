(() => {
  "use strict";

  const ROOT_SELECTOR = "[data-vpnku-root]";
  const ENDPOINT_PLANS = "/api/plans";
  const ENDPOINT_PAY   = "/api/payments/create";

  const q  = (sel, ctx) => (ctx || document).querySelector(sel);
  const fmtRp = (n) => new Intl.NumberFormat("id-ID", { style:"currency", currency:"IDR", maximumFractionDigits:0 }).format(Number(n||0));
  const on    = (el, ev, fn, opt) => el && el.addEventListener(ev, fn, opt || false);
  const fmtBandwidth = (gb) => {
    const val = Number(gb)||0;
    return val >= 1000 ? `${(val/1000)} TB` : `${val} GB`;
  };

  const boot = () => {
    const root = q(ROOT_SELECTOR);
    if (!root) return;

    if (root.__vpnku_inited) return;
    root.__vpnku_inited = true;

    const yEl            = q("#y", root);
    const plansWrap      = q("#plans", root);
    const checkout       = q("#checkout", root);
    const closeCheckout  = q("#closeCheckout", root);
    const coForm         = q("#coForm", root);
    const coMsg          = q("#coMsg", root);
    const btnBayar       = q("#btnBayar", root);
    const tos            = q("#tos", root);

    const summaryPlan     = q("#summaryPlan", root);
    const summarySubtotal = q("#summarySubtotal", root);
    const summaryDiskon   = q("#summaryDiskon", root);
    const summaryKodeUnik = q("#summaryKodeUnik", root);
    const summaryTotal    = q("#summaryTotal", root);
    const summaryProtocol = q("#summaryProtocol", root);

    const durasiEl   = q("#durasi", root);
    const protocolEl = q("#protocol", root);

    const ctaTop  = q("#ctaTop", root);
    const ctaHero = q("#ctaHero", root);

    if (yEl) yEl.textContent = String(new Date().getFullYear());

    let plans = [];
    let selectedPlanId = null;

    const updateProtocolSummary = () => {
      if (!summaryProtocol || !protocolEl) return;
      const label = protocolEl.options?.[protocolEl.selectedIndex]?.text || "-";
      summaryProtocol.textContent = label || "-";
    };

    on(protocolEl, "change", updateProtocolSummary);
    updateProtocolSummary();

    const loadPlans = async () => {
      if (!plansWrap) return;
      try {
        const res = await fetch(ENDPOINT_PLANS, { headers: { "Accept": "application/json" } });
        const j   = await res.json().catch(() => ({}));
        plans     = Array.isArray(j) ? j : (Array.isArray(j?.plans) ? j.plans : []);
    
        plans = plans.filter(p => {
          const s = Number(p.stock);
          return !Number.isFinite(s) || s > 0;
        });
    
        if (!plans.length) {
          plansWrap.innerHTML = `<div class="text-slate-600 dark:text-slate-400">Paket belum tersedia.</div>`;
          return;
        }
    
        selectedPlanId = plans[0].id || null;
        
        plansWrap.innerHTML = plans.map(p => `
          <article class="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm flex flex-col
                          dark:border-slate-700 dark:bg-slate-900">
            <div class="flex items-center gap-2">
              <h3 class="text-xl font-bold text-slate-900 dark:text-white">${p.nama}</h3>
              ${p.country ? `<img src="https://flagcdn.com/24x18/${p.country}.png" 
                             alt="${p.country}" class="inline-block w-6 h-4 rounded-sm border" />` : ''}
            </div>
            <p class="mt-1 text-slate-600 dark:text-slate-400">${p.deskripsi ?? ""}</p>
            <div class="mt-4 text-3xl font-extrabold text-slate-900 dark:text-white">${fmtRp(p.harga)}
              <span class="text-base font-medium text-slate-500 dark:text-slate-400">/bln</span>
            </div>
            <ul class="mt-4 text-sm text-slate-600 dark:text-slate-400 space-y-1">
              <li>Bandwidth: ${fmtBandwidth(p.bandwidth)}</li>
              <li>Kecepatan: ${p.speed ?? "-" }+</li>
              <li>Perangkat: ${p.device ?? "-" } Device</li>
              ${Number.isFinite(Number(p.stock)) ? `<li>Stok tersisa: ${p.stock}</li>` : ``}
            </ul>
            <button type="button" data-plan="${p.id}"
              class="mt-6 inline-flex items-center justify-center rounded-xl border border-slate-300 px-5 py-3 font-semibold hover:bg-slate-50
                     dark:border-slate-600 dark:hover:bg-slate-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-400
                     focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-900">Pilih</button>
          </article>
        `).join("");
      } catch {
        plansWrap.innerHTML = `<div class="text-slate-600 dark:text-slate-400">Gagal memuat paket.</div>`;
      }
    };

    const recompute = () => {
      if (!plans?.length) return;
      const plan    = plans.find(p => p.id === selectedPlanId) || plans[0];
      const bulan   = Number(durasiEl?.value || 1);
      const subtotal= (Number(plan?.harga) || 0) * bulan;
      const diskon  = bulan >= 12 ? Math.round(subtotal * 0.15) : (bulan >= 3 ? Math.round(subtotal * 0.05) : 0);

      if (summaryPlan)     summaryPlan.textContent     = `${plan?.nama ?? "-"} x ${bulan} bln`;
      if (summarySubtotal) summarySubtotal.textContent = fmtRp(subtotal);
      if (summaryDiskon)   summaryDiskon.textContent   = fmtRp(diskon);
      if (summaryKodeUnik) summaryKodeUnik.textContent = "–";
      if (summaryTotal)    summaryTotal.textContent    = fmtRp(subtotal - diskon);
      if (summaryProtocol && protocolEl && !protocolEl.value) summaryProtocol.textContent = "-";
    };

    const openCheckout = () => {
      if (checkout) {
        checkout.classList.remove("hidden");
        checkout.setAttribute("aria-hidden","false");
      }
      recompute();
    };
    const closeModal = () => {
      if (checkout) {
        checkout.classList.add("hidden");
        checkout.setAttribute("aria-hidden","true");
      }
    };

    on(ctaTop,  "click", openCheckout, { passive: true });
    on(ctaHero, "click", openCheckout, { passive: true });
    on(closeCheckout, "click", closeModal);

    on(checkout, "click", (e) => {
      if (e.target === checkout) closeModal();
    });
    on(window, "keydown", (e) => {
      if (e.key === "Escape") closeModal();
    });

    on(plansWrap, "click", (e) => {
      const btn = e.target?.closest?.("button[data-plan]");
      if (!btn) return;
      selectedPlanId = btn.getAttribute("data-plan");
      openCheckout();
    });

    on(durasiEl, "change", recompute, { passive: true });

    const validateForm = () => {
      if (!tos?.checked) return "Centang persetujuan terlebih dahulu.";
      if (!protocolEl?.value) return "Silakan pilih protokol.";
      const nama = coForm?.nama?.value?.trim();
      const wa   = coForm?.wa?.value?.trim();
      if (!nama) return "Username wajib diisi.";
      if (!wa)   return "Nomor WhatsApp wajib diisi.";
      return "";
    };

    on(coForm, "submit", async (e) => {
      e.preventDefault();
      if (!coMsg) return;

      const err = validateForm();
      if (err) { coMsg.textContent = err; return; }

      const plan = plans.find(p => p.id === selectedPlanId) || plans?.[0];
      if (!plan) { coMsg.textContent = "Paket tidak tersedia."; return; }

      const fd = new FormData(coForm);
      const payload = {
        wa:       String(fd.get("wa") || "").trim(),
        nama:     String(fd.get("nama") || "").trim(),
        protocol: String(fd.get("protocol") || "").trim(),
        bulan:    Number(fd.get("durasi") || 1),
        planId:    plan.id,
        device:    plan.device,
        bandwidth: plan.bandwidth
      };

      if (btnBayar) btnBayar.disabled = true;
      coMsg.textContent = "Membuat order...";

      let resp, json;
      try {
        resp = await fetch(ENDPOINT_PAY, {
          method: "POST",
          headers: { "Content-Type":"application/json" },
          body: JSON.stringify(payload)
        });
        json = await resp.json().catch(() => ({}));
        if (!resp.ok) throw new Error(json?.error || "Gagal membuat order");
        if (json?.paymentUrl) window.location.href = json.paymentUrl;
        else coMsg.textContent = "Order berhasil dibuat, namun URL pembayaran tidak ditemukan.";
      } catch (er) {
        coMsg.textContent = er?.message || "Terjadi kesalahan.";
      } finally {
        if (btnBayar) btnBayar.disabled = false;
      }
    });

    on(q("#copyKodeUnik", root), "click", async () => {
      const v = summaryKodeUnik?.textContent?.trim();
      if (!v || v === "-" || v === "–") return;
      try { await navigator.clipboard.writeText(v); } catch {}
    });

    (async () => {
      await loadPlans();
      recompute();
    })();
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once:true });
  } else {
    boot();
  }
})();