(function(){
  const token = localStorage.getItem('adm_token');
  if (!token) { window.location.href = '/login'; return; }

  const headers = { 'Authorization': 'Bearer ' + token, 'Accept':'application/json', 'Content-Type':'application/json' };

  const tabBtns = document.querySelectorAll('.tabbtn');
  function showTab(name){
    document.getElementById('tab-orders').classList.toggle('hidden',   name!=='orders');
    document.getElementById('tab-plans').classList.toggle('hidden',    name!=='plans');
    document.getElementById('tab-account').classList.toggle('hidden',  name!=='account');
    tabBtns.forEach(b => {
      const active = b.dataset.tab===name;
      b.classList.toggle('bg-white', active);
      b.classList.toggle('border',   active);
      b.classList.toggle('border-slate-200', active);
      b.classList.toggle('shadow-sm', active);
    });
  }
  tabBtns.forEach(b => b.addEventListener('click', ()=>showTab(b.dataset.tab)));
  showTab('orders');

  document.getElementById('logout').addEventListener('click', ()=>{
    localStorage.removeItem('adm_token');
    window.location.href = '/login';
  });

  async function loadStats(){
    try{
      const r = await fetch('/api/admin/stats', { headers });
      const j = await r.json();
      const s = j.stats || {};
      const el = document.getElementById('stats');
      el.innerHTML = [
        ['Total Order', s.orders_total || 0],
        ['Paid Order', s.orders_paid || 0],
        ['Revenue', new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(s.revenue_paid||0)]
      ].map(([k,v])=>`
        <div class="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm
                    dark:border-slate-700 dark:bg-slate-900">
          <div class="text-sm text-slate-500 dark:text-slate-400">${k}</div>
          <div class="mt-1 text-2xl font-extrabold">${v}</div>
        </div>
      `).join('');
    }catch{}
  }
  loadStats();

  const tbody = document.getElementById('tbody');
  const qEl = document.getElementById('q');
  const paidEl = document.getElementById('paid');
  const pageinfo = document.getElementById('pageinfo');
  let page=1, limit=20, total=0;

  function fmtRp(n){ return new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n||0); }
  function fmtBW(n){ const v=Number(n)||0; return v>=1000 ? (v/1000)+' TB' : v+' GB'; }

  async function loadOrders(){
    const params = new URLSearchParams();
    if(qEl.value.trim()) params.set('q', qEl.value.trim());
    if(paidEl.value!=='') params.set('paid', paidEl.value);
    params.set('page', page);
    params.set('limit', limit);
    const r = await fetch('/api/admin/orders?'+params.toString(), { headers });
    const j = await r.json();
    if(!j.ok){ tbody.innerHTML = `<tr><td colspan="11" class="py-4 text-slate-500">Gagal load</td></tr>`; return; }
    total = j.total||0;
    if(!j.items.length){
      tbody.innerHTML = `<tr><td colspan="11" class="py-4 text-center text-slate-500">Tidak ada data</td></tr>`;
      pageinfo.textContent = `Page ${page} / ${Math.max(1, Math.ceil(total/limit))}`;
      return;
    }
    tbody.innerHTML = j.items.map(o=>`
  <tr class="border-t border-slate-100 dark:border-slate-800">
    <td class="py-2 px-3 text-center whitespace-nowrap min-w-[180px]">
      <div class="font-mono text-xs">${o.id}</div>
    </td>
    <td class="px-3 text-center"><div class="font-semibold">${o.nama || '-'}</div></td>
    <td class="px-3 text-center whitespace-nowrap min-w-[120px]"><div class="text-slate-600 dark:text-slate-300">${o.wa || '-'}</div></td>
    <td class="px-3 text-center">${o.plan_id || '-'}</td>
    <td class="px-3 text-center">${(o.protocol || '-').toUpperCase()}</td>
    <td class="px-3 text-center">${fmtBW(o.bandwidth)}</td>
    <td class="px-3 text-center">${o.device || 0}</td>
    <td class="px-3 text-center">${fmtRp(o.total)}</td>
    <td class="px-3 text-center">
      ${o.paid
        ? '<span class="inline-block px-2 py-1 text-xs rounded bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300">PAID</span>'
        : '<span class="inline-block px-2 py-1 text-xs rounded bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300">UNPAID</span>'}
    </td>
    <td class="px-3 text-center text-xs whitespace-nowrap min-w-[150px]">${new Date(o.created_at).toLocaleString('id-ID')}</td>
    <td class="px-3 text-center">
      <div class="flex justify-center gap-2">
        ${o.paid
          ? `<button data-act="unpaid" data-id="${o.id}" class="rounded-lg border px-2 py-1 text-xs dark:border-slate-700">Unpaid</button>`
          : `<button data-act="paid" data-id="${o.id}" class="rounded-lg border px-2 py-1 text-xs dark:border-slate-700">Paid</button>`}
        <a href="/order/${encodeURIComponent(o.id)}/creds" class="rounded-lg border px-2 py-1 text-xs dark:border-slate-700" target="_blank">See</a>
        <button data-act="del" data-id="${o.id}" class="rounded-lg border px-2 py-1 text-xs text-red-600 border-red-300 dark:border-red-700">Delete</button>
      </div>
    </td>
  </tr>
`).join('');
    pageinfo.textContent = `Page ${page} / ${Math.max(1, Math.ceil(total/limit))}`;
  }
  loadOrders();

  document.getElementById('ref').addEventListener('click', ()=>{ page=1; loadOrders(); });
  document.getElementById('prev').addEventListener('click', ()=>{ if(page>1){page--; loadOrders();} });
  document.getElementById('next').addEventListener('click', ()=>{ const max=Math.max(1, Math.ceil(total/limit)); if(page<max){page++; loadOrders();} });
  qEl.addEventListener('keydown', (e)=>{ if(e.key==='Enter'){ page=1; loadOrders(); } });
  paidEl.addEventListener('change', ()=>{ page=1; loadOrders(); });

  document.getElementById('tbody').addEventListener('click', async (e)=>{
    const b = e.target.closest('button[data-act],a[data-act]');
    if(!b) return;

    const id  = b.getAttribute('data-id');
    const act = b.getAttribute('data-act');

    if (act === 'del') {
      if (!confirm('Hapus order ini? Tindakan tidak dapat dibatalkan.')) return;
      const r = await fetch(`/api/admin/orders/${encodeURIComponent(id)}`, { method:'DELETE', headers });
      const j = await r.json().catch(()=>({ ok:false }));
      if(!j.ok){ alert(j.error || 'Gagal hapus'); return; }
      loadOrders(); loadStats();
      return;
    }

    const url = act==='paid' ? `/api/admin/orders/${encodeURIComponent(id)}/mark-paid`
                             : `/api/admin/orders/${encodeURIComponent(id)}/mark-unpaid`;
    const r = await fetch(url, { method:'PATCH', headers });
    const j = await r.json();
    if(!j.ok){ alert('Gagal update'); return; }
    loadOrders(); loadStats();
  });

  let plansState = [];
  const plansTbody   = document.getElementById('plansTbody');
  const plansMsgV2   = document.getElementById('plansMsgV2');
  const addPlanForm  = document.getElementById('addPlanForm');
  const addPlanMsg   = document.getElementById('addPlanMsg');
  const saveBtnV2    = document.getElementById('savePlansV2');
  const reloadBtn    = document.getElementById('reloadPlans');

  function sanitizeStr(v){ return (v==null ? '' : String(v).trim()); }
  const NUM_FIELDS = new Set(['harga','bandwidth','device','stock']);

  function renderPlansTable(){
    if(!plansTbody) return;
    if(!plansState.length){
      plansTbody.innerHTML = `<tr><td colspan="10" class="py-4 text-center text-slate-500 dark:text-slate-400">Belum ada plan</td></tr>`;
      return;
    }
    plansTbody.innerHTML = plansState.map((p, idx)=>`
      <tr class="border-t border-slate-100 dark:border-slate-800" data-idx="${idx}">
        <td class="py-2"><input data-k="id" value="${sanitizeStr(p.id)}"  class="w-28 rounded-lg border px-2 py-1 text-xs border-slate-300 bg-white dark:border-slate-700 dark:bg-slate-800"></td>
        <td><input data-k="nama"      value="${sanitizeStr(p.nama)}"      class="w-32 rounded-lg border px-2 py-1 text-xs border-slate-300 bg-white dark:border-slate-700 dark:bg-slate-800"></td>
        <td><input data-k="deskripsi" value="${sanitizeStr(p.deskripsi)}" class="w-40 rounded-lg border px-2 py-1 text-xs border-slate-300 bg-white dark:border-slate-700 dark:bg-slate-800"></td>
        <td><input data-k="harga"     value="${sanitizeStr(p.harga)}"     class="w-24 rounded-lg border px-2 py-1 text-xs border-slate-300 bg-white dark:border-slate-700 dark:bg-slate-800" inputmode="numeric"></td>
        <td><input data-k="speed"     value="${sanitizeStr(p.speed)}"     class="w-28 rounded-lg border px-2 py-1 text-xs border-slate-300 bg-white dark:border-slate-700 dark:bg-slate-800"></td>
        <td><input data-k="bandwidth" value="${sanitizeStr(p.bandwidth)}" class="w-24 rounded-lg border px-2 py-1 text-xs border-slate-300 bg-white dark:border-slate-700 dark:bg-slate-800" inputmode="numeric"></td>
        <td><input data-k="device"    value="${sanitizeStr(p.device)}"    class="w-20 rounded-lg border px-2 py-1 text-xs border-slate-300 bg-white dark:border-slate-700 dark:bg-slate-800" inputmode="numeric"></td>
        <td><input data-k="ext_api"   value="${sanitizeStr(p.ext_api)}"   class="w-44 rounded-lg border px-2 py-1 text-xs border-slate-300 bg-white dark:border-slate-700 dark:bg-slate-800"></td>
        <td>
          <input data-k="stock" value="${sanitizeStr(p.stock)}"
                 class="w-20 rounded-lg border px-2 py-1 text-xs border-slate-300 bg-white dark:border-slate-700 dark:bg-slate-800"
                 inputmode="numeric" placeholder="kosong=tak terbatas">
        </td>
        <td>
          <button class="btn-del-plan rounded-lg border px-2 py-1 text-xs text-red-600 border-red-300 dark:border-red-700"" data-id="${sanitizeStr(p.id)}">Delete</button>
        </td>
      </tr>
    `).join('');
  }

  async function loadPlans(){
    plansMsgV2.textContent = 'Memuat...';
    try{
      const r = await fetch('/api/admin/plans', { headers });
      const j = await r.json();
      if(j.ok) {
        plansState = Array.isArray(j.plans) ? structuredClone(j.plans) : [];
        renderPlansTable();
        plansMsgV2.textContent = ``;
      }else{
        plansMsgV2.textContent = j.error || 'Gagal memuat plans';
      }
    }catch(e){
      plansMsgV2.textContent = 'Gagal memuat plans';
    }
  }
  loadPlans();

  plansTbody?.addEventListener('input', (e)=>{
    const input = e.target.closest('input[data-k]');
    if(!input) return;
    const tr = e.target.closest('tr[data-idx]');
    const idx = Number(tr?.dataset?.idx ?? -1);
    if(idx < 0) return;
    const key = input.getAttribute('data-k');
    let val = input.value;

    if (NUM_FIELDS.has(key)) {
      if (val === '' || val == null) {
        val = undefined; // kosong → tidak dikirim
      } else {
        const n = Number(val);
        val = Number.isFinite(n) ? n : undefined;
      }
    }

    plansState[idx][key] = val;
  });

  plansTbody?.addEventListener('click', (e)=>{
    const btn = e.target.closest('button.btn-del-plan');
    if(!btn) return;
    const tr = e.target.closest('tr[data-idx]');
    const idx = Number(tr?.dataset?.idx ?? -1);
    if(idx < 0) return;
    const { id } = plansState[idx] || {};
    if(!confirm(`Hapus plan "${id||idx}"?`)) return;
    plansState.splice(idx, 1);
    renderPlansTable();
  });

  document.getElementById('savePlansV2')?.addEventListener('click', async ()=>{
    plansMsgV2.textContent = 'Menyimpan...';
    try{
      const ids = new Set();
      const payload = plansState.map(p => {
        const obj = { ...p };
        if(!obj.id || !obj.nama){ throw new Error('Pastikan id, nama terisi.'); }
        const sid = String(obj.id).trim().toLowerCase();
        if(ids.has(sid)) throw new Error(`id duplikat: ${obj.id}`);
        ids.add(sid);

        for (const k of NUM_FIELDS) {
          const v = obj[k];
          if (v === '' || v == null) {
            delete obj[k];
          } else if (typeof v !== 'number') {
            const n = Number(v);
            if (Number.isFinite(n)) obj[k] = n; else delete obj[k];
          }
        }
        return obj;
      });

      const r = await fetch('/api/admin/plans', {
        method:'POST',
        headers,
        body: JSON.stringify({ plans: payload })
      });
      const j = await r.json();
      if(!j.ok){ plansMsgV2.textContent = j.error || 'Gagal simpan'; return; }
      plansMsgV2.textContent = 'Tersimpan ✔';
      loadPlans();
    }catch(e){
      plansMsgV2.textContent = e?.message || 'Gagal menyimpan (cek data)';
    }
  });

  document.getElementById('reloadPlans')?.addEventListener('click', ()=> loadPlans());

  const admForm = document.getElementById('admForm');
  const admNama = document.getElementById('admNama');
  const admWa   = document.getElementById('admWa');
  const admPass = document.getElementById('admPass');
  const admPass2= document.getElementById('admPass2');
  const admMsg  = document.getElementById('admMsg');
  function setAdmMsg(s){ if(admMsg) admMsg.textContent = s || ''; }

  async function loadAdminAccount(){
    if (!admForm) return;
    setAdmMsg('Memuat...');
    try{
      const r = await fetch('/api/admin/account', { headers });
      const j = await r.json();
      if(!j.ok) { setAdmMsg(j.error || 'Gagal memuat akun'); return; }
      admNama.value = j.user?.nama || '';
      admWa.value   = j.user?.wa   || '';
      setAdmMsg('');
    }catch(e){
      setAdmMsg('Gagal memuat akun');
    }
  }
  loadAdminAccount();

  admForm?.addEventListener('submit', async (e)=>{
    e.preventDefault();
    setAdmMsg('');

    const nama = (admNama.value || '').trim();
    const wa   = (admWa.value || '').trim();
    const p1   = (admPass.value || '');
    const p2   = (admPass2.value || '');

    if (p1 || p2) {
      if (p1 !== p2) { setAdmMsg('Ulangi password tidak sama'); return; }
      if (p1.length < 6) { setAdmMsg('Password minimal 6 karakter'); return; }
    }

    try{
      setAdmMsg('Menyimpan...');
      const r = await fetch('/api/admin/account', {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ nama, wa, password: p1 || undefined })
      });
      const j = await r.json();
      if (!j.ok) { setAdmMsg(j.error || 'Gagal menyimpan'); return; }

      localStorage.setItem('adm_token', j.token);
      headers['Authorization'] = 'Bearer ' + j.token;

      setAdmMsg('Tersimpan ✔');
      loadStats();
    }catch(e){
      setAdmMsg('Gagal menyimpan');
    }finally{
      admPass.value = '';
      admPass2.value = '';
    }
  });

})();