<?php
$db_config = [
    'servername' => '127.0.0.1',
    'username' => 'radmon',
    'password' => 'radmon',
    'dbname' => 'radmon'
];
?>
