document.write('MUTIARA.NET')
//Sesuaikan
//Jangan Menghapus kode scriptnya