document.write('<a href="tel:+6285372687484" class="btn btn-text-primary" >PANGGIL</a>')
//Ganti +6285372687484 dengan NO Telepon Agan (Gunakan Kode Negara +62)
//Jangan Menghapus kode scriptnya