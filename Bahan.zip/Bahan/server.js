const express = require("express");
const fs = require("fs");
const path = require("path");
const router = express.Router();
const multer = require("multer");
const upload = multer({ dest: "uploads/" });
const { db } = require('./db'); 

module.exports = (getSock, connectToWhatsApp) => {
  router.get("/status", (req, res) => {
    const sock = getSock();
    const isLoggedIn = sock && sock.user ? true : false;
    res.json({ loggedIn: isLoggedIn });
  });
    
  router.post("/send-message", async (req, res) => {
    const {
      to,
      message
    } = req.body;
    const sock = getSock();
    if(!sock || sock.authState === "Disconnected") {
      await connectToWhatsApp();
      if(sock.authState === "Disconnected") {
        return res.status(500).send("Koneksi WhatsApp tidak tersedia, coba lagi nanti");
      }
    }
    try {
      await sock.sendMessage(to + "@s.whatsapp.net", {
        text: message
      });
      res.send("Pesan terkirim!");
    }
    catch (error) {
      res.status(500).send("Gagal mengirim pesan");
    }
  });
  router.post("/send-image", upload.single("image"), async (req, res) => {
    const sock = getSock();
    const { to, caption } = req.body;

    if (!sock || sock.authState === "Disconnected") {
      await connectToWhatsApp();
      if (sock.authState === "Disconnected") {
        return res.status(500).send("Koneksi WhatsApp tidak tersedia, coba lagi nanti");
      }
    }

    if (!req.file) {
      return res.status(400).send("Gambar tidak ditemukan dalam permintaan");
    }

    try {
      const buffer = fs.readFileSync(req.file.path);
      await sock.sendMessage(to + "@s.whatsapp.net", {
        image: buffer,
        caption: caption || "",
      });

      fs.unlinkSync(req.file.path);

      res.send("Gambar berhasil dikirim!");
    } catch (error) {
      console.error(error);
      res.status(500).send("Gagal mengirim gambar");
    }
  });
  router.post("/send-document", upload.single("document"), async (req, res) => {
    const sock = getSock();
    const { to, caption } = req.body;

    if (!sock || sock.authState === "Disconnected") {
      await connectToWhatsApp();
      if (sock.authState === "Disconnected") {
        return res.status(500).send("Koneksi WhatsApp tidak tersedia, coba lagi nanti");
      }
    }

    if (!req.file) {
      return res.status(400).send("Dokumen tidak ditemukan dalam permintaan");
    }

    try {
      const filePath = req.file.path;
      const buffer = fs.readFileSync(filePath);
      const mimeType = req.file.mimetype;
      const fileName = req.file.originalname;

      await sock.sendMessage(to + "@s.whatsapp.net", {
        document: buffer,
        mimetype: mimeType,
        fileName: fileName,
        caption: caption || "",
      });

      fs.unlinkSync(filePath);

      res.send("Dokumen berhasil dikirim!");
    } catch (error) {
      console.error(error);
      res.status(500).send("Gagal mengirim dokumen");
    }
  });
  router.get("/", (req, res) => {
  db.query("SELECT username, whatsapp_number FROM client ORDER BY id DESC", (err, results) => {
    if (err) {
      console.error("Gagal mengambil data:", err);
      return res.status(500).send("Gagal mengambil data dari database");
    }

    const options = results
      .map(row => `<option value="${row.whatsapp_number}">${row.whatsapp_number} - ${row.username}</option>`)
      .join("");

    res.send(`
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>WhatsApp Web</title>
    <link rel="icon" href="whatsapp.png" />
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eee;
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            box-sizing: border-box;
        }

        h1 {
            text-align: center;
            color: #075e54;
            margin-bottom: 20px;
        }
        #messageForm {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            max-width: 400px;
            width: 100%;
        }
        label {
            font-weight: 700;
            display: block;
            margin: 10px 0 5px;
        }
        select,
        textarea,
        input[type="file"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }
        textarea {
            resize: vertical;
        }
        button {
            background-color: #075e54;
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 10px;
            width: 100%;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #0b8b6d;
        }
        
        .form-group {
          margin-bottom: 15px;
        }
        label.checkbox-label {
          font-weight: 700;
          display: flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
        }
        select, input[type="text"], textarea, input[type="file"] {
          width: 100%;
          padding: 10px;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
        }
        
        .toggle-buttons {
          display: flex;
          gap: 10px;
          margin-bottom: 15px;
        }
        .toggle-button {
          flex: 1;
          padding: 10px;
          text-align: center;
          cursor: pointer;
          border: 1px solid #075e54;
          border-radius: 4px;
          user-select: none;
          font-weight: 700;
          background-color: #eee;
          color: #075e54;
          transition: background-color 0.3s, color 0.3s;
        }
        .toggle-button.active {
          background-color: #075e54;
          color: white;
        }
        select, input[type="text"] {
          width: 100%;
          padding: 10px;
          margin-bottom: 15px;
          border-radius: 4px;
          border: 1px solid #ccc;
          box-sizing: border-box;
        }
        
    </style>
</head>
<body>

<form id="messageForm">
  
  <div class="toggle-buttons">
    <div id="btnSelect" class="toggle-button active">Pilih Nomor</div>
    <div id="btnManual" class="toggle-button">Input Manual</div>
  </div>

  <div id="selectContainer">
    <label for="toSelect">Nomor Tujuan:</label>
    <select id="toSelect" name="toSelect" required>
      <option value="">-- Pilih Nomor --</option>
      ${options}
    </select>
  </div>

  <div id="manualContainer" style="display:none;">
    <label for="toManual">Nomor Tujuan:</label>
    <input type="text" id="toManual" name="toManual" placeholder="Contoh: 6281234567890" />
  </div>

  <label for="message">Pesan:</label>
  <textarea id="message" name="message" rows="4" style="width: 100%; padding: 10px; margin-bottom: 15px; border-radius: 4px; border: 1px solid #ccc; box-sizing: border-box;"></textarea>

  <label for="file">Lampiran (gambar atau dokumen):</label>
  <input type="file" id="file" name="file" accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt,.zip,.rar,.ppt,.pptx" style="width: 100%; margin-bottom: 15px;" />

  <button type="submit" style="background-color: #075e54; color: white; border: none; padding: 10px; border-radius: 4px; width: 100%; cursor: pointer; font-size: 16px;">Kirim</button>
</form>

<script>
  const btnSelect = document.getElementById('btnSelect');
  const btnManual = document.getElementById('btnManual');
  const selectContainer = document.getElementById('selectContainer');
  const manualContainer = document.getElementById('manualContainer');
  const toSelect = document.getElementById('toSelect');
  const toManual = document.getElementById('toManual');

  btnSelect.classList.add('active');
  toSelect.required = true;
  toManual.required = false;

  btnSelect.addEventListener('click', () => {
    btnSelect.classList.add('active');
    btnManual.classList.remove('active');
    selectContainer.style.display = 'block';
    manualContainer.style.display = 'none';
    toSelect.required = true;
    toManual.required = false;
  });

  btnManual.addEventListener('click', () => {
    btnManual.classList.add('active');
    btnSelect.classList.remove('active');
    selectContainer.style.display = 'none';
    manualContainer.style.display = 'block';
    toSelect.required = false;
    toManual.required = true;
  });

document.getElementById('messageForm').onsubmit = async function(event) {
  event.preventDefault();

  const useManual = btnManual.classList.contains('active');
  const to = useManual ? toManual.value.trim() : toSelect.value;

  if (!to) {
    alert('Nomor tujuan belum diisi.');
    return;
  }

  const message = document.getElementById('message').value.trim();
  const fileInput = document.getElementById('file');
  const file = fileInput.files[0];

  if (file) {
    const isImage = file.type.startsWith('image/');
    const endpoint = isImage ? '/send-image' : '/send-document';
    const fieldName = isImage ? 'image' : 'document';

    const formData = new FormData();
    formData.append('to', to);
    formData.append('caption', message);
    formData.append(fieldName, file);

    const response = await fetch(endpoint, {
      method: 'POST',
      body: formData
    });

    const result = await response.text();
    alert(result);
    return;
  }

  const response = await fetch('/send-message', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ to, message })
  });

  const result = await response.text();
  alert(result);
};
</script>

</body>
</html>
    `);
  });
});

  router.get("/login", async (req, res) => {
    try {
      const sock = getSock();

      if (sock && sock.user) {
        return res.send(`
            <!DOCTYPE html>
            <html lang="id">
            <head>
              <meta charset="UTF-8" />
              <meta name="viewport" content="width=device-width, initial-scale=1.0" />
              <title>Whatsapp Web</title>
              <link rel="icon" href="whatsapp.png" />
              <style>
                body {
                  margin: 0;
                  font-family: sans-serif;
                  background: #eee;
                  min-height: 100vh;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                }
            
                .card {
                  background-color: #ffffff;
                  border-radius: 16px;
                  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
                  padding: 30px;
                  text-align: center;
                  max-width: 360px;
                  animation: fade-in 0.8s ease-out;
                }
            
                .icon {
                  width: 64px;
                  height: 64px;
                  color: #25D366;
                  margin: 0 auto 16px;
                }
            
                h1 {
                  font-size: 20px;
                  color: #075e54;
                  margin-bottom: 10px;
                }
            
                p {
                  color: #444;
                  font-size: 14px;
                  margin-bottom: 20px;
                }
            
                a.button {
                  display: inline-block;
                  background-color: #25D366;
                  color: white;
                  padding: 10px 20px;
                  border-radius: 10px;
                  text-decoration: none;
                  font-weight: bold;
                  transition: background 0.3s;
                  font-size: 14px;
                }
            
                a.button:hover {
                  background-color: #1ebc5b;
                }
            
                @keyframes fade-in {
                  from {
                    opacity: 0;
                    transform: translateY(20px);
                  }
                  to {
                    opacity: 1;
                    transform: translateY(0);
                  }
                }
              </style>
            </head>
            <body>
              <div class="card">
                <svg class="icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round"
                    d="M9 12l2 2l4-4m5 2a9 9 0 1 1 -18 0a9 9 0 0 1 18 0z" />
                </svg>
                <h1>Anda Sudah Berhasil Login!</h1>
                <p>Nomor Anda berhasil ditautkan ke sistem!</p>
                <a class="button">${
                  sock.user.id.split("@")[0].split(":")[0].replace(/^62/, "0")
                }</a>
              </div>
            </body>
        </html>
        
        `);
      }

    res.send(`
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>WhatsApp Web</title>
  <link rel="icon" href="whatsapp.png" />
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f0f2f5;
      color: #111;
    }

    .header {
      background-color: #00a884;
      padding: 14px 24px;
      color: white;
      font-size: 18px;
      display: flex;
      justify-content: space-between; /* penting agar tombol di kanan */
      align-items: center;
      box-shadow: 0 1px 3px rgba(0,0,0,0.2);
    }

    .download-button {
      background-color: #ffffff;
      color: #00a884;
      padding: 8px 16px;
      font-size: 14px;
      font-weight: bold;
      border: none;
      border-radius: 20px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .download-button:hover {
      background-color: #e6f3f0;
    }

    .main-container {
      display: flex;
      max-width: 1000px;
      margin: 40px auto;
      background-color: white;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .left-section, .right-section {
      padding: 40px 30px;
      flex: 1;
    }

    .left-section {
      border-right: 1px solid #ddd;
    }

    .left-section h2 {
      color: #41525d;
      font-size: 24px;
      margin-top: 0;
    }

    .left-section p {
      margin: 8px 0 20px;
      color: #667781;
    }

    .left-section ol {
      padding-left: 20px;
      color: #3b4a54;
    }

    .left-section a {
      display: block;
      margin-top: 15px;
      color: #008069;
      text-decoration: none;
      font-size: 14px;
    }

    .left-section a:hover {
      text-decoration: underline;
    }

    .checkbox-container {
      display: flex;
      align-items: center;
      margin-top: 20px;
    }

    .checkbox-container input {
      margin-right: 10px;
    }

    .right-section {
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: #f8f9fa;
    }

    .qr-code img {
      width: 240px;
      height: auto;
      border-radius: 10px;
      box-shadow: 0 0 6px rgba(0, 0, 0, 0.1);
    }

    .footer {
      text-align: center;
      font-size: 13px;
      color: #8696a0;
      margin-top: 20px;
      padding-bottom: 20px;
    }

    @media (max-width: 768px) {
      .main-container {
        flex-direction: column;
        margin: 20px;
      }

      .left-section, .right-section {
        padding: 20px;
      }

      .right-section {
        border-top: 1px solid #ddd;
      }
    }
  </style>
</head>
<body>

<div class="header">
  <div class="logo">WhatsApp</div>
  <button class="download-button">Unduh</button>
</div>

  <div class="main-container">
    <div class="left-section">
      <h2>Gunakan WhatsApp di komputer Anda</h2>
      <p>Untuk menggunakan WhatsApp Web, ikuti langkah berikut:</p>
      <ol>
        <li>Buka WhatsApp di ponsel Anda</li>
        <li>Ketuk Menu <strong>⋮</strong> di Android, atau Pengaturan <strong>⚙️</strong> di iPhone</li>
        <li>Pilih <strong>Perangkat tertaut</strong></li>
        <li>Kemudian <strong>Tautkan Perangkat</strong></li>
        <li>Arahkan kamera ponsel ke kode QR di layar ini</li>
      </ol>

      <a href="#">Perlu bantuan untuk memulai?</a>
      <a href="#">Login dengan nomor telepon</a>

      <div class="checkbox-container">
        <input type="checkbox" id="stayLoggedIn" checked />
        <label for="stayLoggedIn">Tetap masuk</label>
      </div>
    </div>

    <div class="right-section">
      <div class="qr-code">
        <img id="qrImage" src="qr_code.png" alt="Kode QR" />
      </div>
    </div>
  </div>

  <div class="footer">
    🔒 Pesan pribadi Anda terenkripsi secara end-to-end
  </div>

  <script>
    setInterval(() => {
      const qrImg = document.getElementById("qrImage");
      qrImg.src = "qr_code.png?t=" + new Date().getTime();
    }, 10000);

    setInterval(async () => {
      try {
        const res = await fetch("/status");
        const data = await res.json();
        if (data.loggedIn) {
          window.location.reload();
        }
      } catch (err) {
        console.error("Gagal cek status login", err);
      }
    }, 3000);
  </script>

</body>
</html>

      `);

    } catch (err) {
      console.error("Gagal render halaman login:", err);
      res.status(500).send("Terjadi kesalahan di server.");
    }
  });

  return router;
};